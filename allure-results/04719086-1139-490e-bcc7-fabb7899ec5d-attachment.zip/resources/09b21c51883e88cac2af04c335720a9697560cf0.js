(function() {
	(document.createElement('IMG')).src = 'https://cm.idealmedia.io/i.gif?muidf=pbt6iwGwbHxm&gdpr=0&gdpr_consent=&us_privacy=';
	var d834098 = document.createElement('div');d834098.innerHTML="<iframe src=\"https://onetag-sys.com/usync/?pubId=7cd9d7c7c13ff36&sync_id=pbt6iwGwbHxm&gdpr=0&gdpr_consent=&us_privacy=\" style=\"display: none;\"></iframe>";document.body.appendChild(d834098);
	var d43070 = document.createElement('div');d43070.innerHTML="<iframe id=\"multisync-iframe\" height=\"0\" width=\"0\" marginwidth=\"0\" marginheight=\"0\" scrolling=\"no\" frameborder=\"0\" src=\"https://secure-assets.rubiconproject.com/utils/xapi/multi-sync.html?p=mgid&endpoint=eu&gdpr=0&gdpr_consent=&us_privacy=\" style=\"border: 0px; display: none;\"></iframe>";document.body.appendChild(d43070);
	(document.createElement('IMG')).src = 'https://ad.360yield.com/server_match?partner_id=1944&gdpr=0&gdpr_consent=&us_privacy=&r=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D665953%26c%3D%7BPUB_USER_ID%7D';
	(document.createElement('IMG')).src = 'https://cm.g.doubleclick.net/pixel?google_nid=marketgid&google_cm=&google_ula={guid}&google_hm=cGJ0Nml3R3diSHht&muidn=pbt6iwGwbHxm&gdpr=0&gdpr_consent=';
	(document.createElement('IMG')).src = 'https://sync.crwdcntrl.net/qmap?c=14777&tp=MIGD&tpid=pbt6iwGwbHxm&gdpr=0&gdpr_consent=';
	(document.createElement('IMG')).src = 'https://ib.adnxs.com/getuid?https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834104%26c%3D%24UID&gdpr=0&gdpr_consent=';
	(document.createElement('IMG')).src = 'https://ssbsync.smartadserver.com/api/sync?callerId=155&gdpr=0&gdpr_consent=&url=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834126%26c%3D%5Bsas_sync_pid%5D%26nwid%3D4577';
	(document.createElement('IMG')).src = 'https://ps.eyeota.net/match?bid=dn2m51u&uid=pbt6iwGwbHxm&gdpr=0&gdpr_consent=';
	(document.createElement('IMG')).src = 'https://sync.inmobi.com/sync?gdpr_consent=&gdpr=0&us_privacy=&gdpr_pd=&source=5&google_push=&retry=&redirect=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834179%26c%3D%7BID5UID%7D';
	(document.createElement('IMG')).src = 'https://creativecdn.com/cm-notify?pi=mgid&gdpr=0&gdpr_consent=&us_privacy=';
	(document.createElement('IMG')).src = 'https://image8.pubmatic.com/AdServer/ImgSync?p=161673&gdpr=0&gdpr_consent=&pu=https%3A%2F%2Fimage4.pubmatic.com%2FAdServer%2FSPug%3FpartnerID%3D161673%26pmc%3DPM_PMC%26pr%3Dhttps%253A%252F%252Fcm.mgid.com%252Fm%253Fcdsp%253D712807%2526c%253D%2523PMUID';
	(document.createElement('IMG')).src = 'https://prebid.a-mo.net/cchain/0?gdpr=0&gdpr_consent=&us_privacy=&cb=https%3A//cm.mgid.com/m%3Fcdsp%3D779131%26c%3D';
	(document.createElement('IMG')).src = 'https://sync.adkernel.com/user-sync?zone=219216&t=image&gdpr=0&gdpr_consent=&us_privacy=&r=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834154%26c%3D%7BUID%7D';
	(document.createElement('IMG')).src = 'https://cm.rtbsystem.com/mgid?c=pbt6iwGwbHxm&gdpr=0&gdpr_consent=&us_privacy=&cd=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D556372%26c%3D%24%7BUSER%7D';
	(document.createElement('IMG')).src = 'https://match.360yield.com/match?external_user_id=pbt6iwGwbHxm&publisher_dsp_id=489&dsp_callback=1&&gdpr=0&gdpr_consent=&r=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834124%26c%3D%7BPUB_USER_ID%7D';
	(document.createElement('IMG')).src = 'https://ssp-sync.criteo.com/user-sync/redirect?profile=342&gdpr_consent=&gdpr=0&gpp=&gpp_sid=&redir=https%3A%2F%2Fcm.mgid.com%2Fm%3Fcdsp%3D834177%26c%3D%24%7BCRITEO_USER_ID%7D';
})()
